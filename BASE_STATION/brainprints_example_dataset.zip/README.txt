
Synthetic brainprints example dataset
Files in directory: /mnt/data/brainprints_example

For each subject subj_1..subj_5:
 - subj_X_connectivity.csv   : N_regions x N_regions symmetric correlation matrix (CSV)
 - subj_X_eeg.npy            : numpy array (channels x samples) with raw EEG (NumPy .npy)
 - subj_X_eeg_sample.csv     : preview CSV (channels x first 1000 samples)

Also:
 - features.csv              : tabular feature vectors extracted for each subject
 - metadata.json             : simple metadata describing files
 - README.txt                : this file
