﻿// Copyright 2014 Keysight Technologies, Inc , Keysight Confidential
namespace DPD_SFP
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series10 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series11 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series12 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title4 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.DPDDemoLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BrowseButton = new System.Windows.Forms.Button();
            this.msLabel2 = new System.Windows.Forms.Label();
            this.msLabel = new System.Windows.Forms.Label();
            this.dBmLabel = new System.Windows.Forms.Label();
            this.CarrFreTxt = new System.Windows.Forms.TextBox();
            this.CarrFreComboBox = new System.Windows.Forms.ComboBox();
            this.NonlinOrderTxt = new System.Windows.Forms.TextBox();
            this.VSASetTxt = new System.Windows.Forms.TextBox();
            this.TimeStopTxt = new System.Windows.Forms.TextBox();
            this.RFPowerTxt = new System.Windows.Forms.TextBox();
            this.NonlinOrderLabel = new System.Windows.Forms.Label();
            this.VSASetLabel = new System.Windows.Forms.Label();
            this.TimeStopLabel = new System.Windows.Forms.Label();
            this.RFPowerLabel = new System.Windows.Forms.Label();
            this.MemOrderTxt = new System.Windows.Forms.TextBox();
            this.InstrAddrTxt = new System.Windows.Forms.TextBox();
            this.TimeStartTxt = new System.Windows.Forms.TextBox();
            this.MemOrderLabel = new System.Windows.Forms.Label();
            this.InstrAddrLabel = new System.Windows.Forms.Label();
            this.TimeStartLabel = new System.Windows.Forms.Label();
            this.CarrFreqLabel = new System.Windows.Forms.Label();
            this.StartButton = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.DPDOutPowerLabel = new System.Windows.Forms.Label();
            this.EVMLabel = new System.Windows.Forms.Label();
            this.ACPLabel = new System.Windows.Forms.Label();
            this.ACPdataGridView2 = new System.Windows.Forms.DataGridView();
            this.ACP_Upper_Orig = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACP_Upper_wDPD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACP_Upper_woDPD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EVMdataGridView = new System.Windows.Forms.DataGridView();
            this.EVM_Orig = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EVM_wDPD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EVM_woDPD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACPdataGridView = new System.Windows.Forms.DataGridView();
            this.ACP_Lower_Orig = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACP_Lower_wDPD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACP_Lower_woDPD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.DPDOutTxt = new System.Windows.Forms.TextBox();
            this.dBmLabel2 = new System.Windows.Forms.Label();
            this.SpectrumButton = new System.Windows.Forms.Button();
            this.LoadwsvLabel = new System.Windows.Forms.Label();
            this.ChooseFileButton = new System.Windows.Forms.Button();
            this.LoadingLabel = new System.Windows.Forms.Label();
            this.RunningLabel = new System.Windows.Forms.Label();
            this.PathLabel = new System.Windows.Forms.Label();
            this.SaveButton = new System.Windows.Forms.Button();
            this.SaveAsButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ACPdataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EVMdataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ACPdataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // DPDDemoLabel
            // 
            this.DPDDemoLabel.AutoSize = true;
            this.DPDDemoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DPDDemoLabel.Location = new System.Drawing.Point(312, 9);
            this.DPDDemoLabel.Name = "DPDDemoLabel";
            this.DPDDemoLabel.Size = new System.Drawing.Size(118, 18);
            this.DPDDemoLabel.TabIndex = 0;
            this.DPDDemoLabel.Text = "DPD SFP Demo";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.BrowseButton);
            this.groupBox1.Controls.Add(this.msLabel2);
            this.groupBox1.Controls.Add(this.msLabel);
            this.groupBox1.Controls.Add(this.dBmLabel);
            this.groupBox1.Controls.Add(this.CarrFreTxt);
            this.groupBox1.Controls.Add(this.CarrFreComboBox);
            this.groupBox1.Controls.Add(this.NonlinOrderTxt);
            this.groupBox1.Controls.Add(this.VSASetTxt);
            this.groupBox1.Controls.Add(this.TimeStopTxt);
            this.groupBox1.Controls.Add(this.RFPowerTxt);
            this.groupBox1.Controls.Add(this.NonlinOrderLabel);
            this.groupBox1.Controls.Add(this.VSASetLabel);
            this.groupBox1.Controls.Add(this.TimeStopLabel);
            this.groupBox1.Controls.Add(this.RFPowerLabel);
            this.groupBox1.Controls.Add(this.MemOrderTxt);
            this.groupBox1.Controls.Add(this.InstrAddrTxt);
            this.groupBox1.Controls.Add(this.TimeStartTxt);
            this.groupBox1.Controls.Add(this.MemOrderLabel);
            this.groupBox1.Controls.Add(this.InstrAddrLabel);
            this.groupBox1.Controls.Add(this.TimeStartLabel);
            this.groupBox1.Controls.Add(this.CarrFreqLabel);
            this.groupBox1.Location = new System.Drawing.Point(12, 85);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(698, 115);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Parameter Setting";
            // 
            // BrowseButton
            // 
            this.BrowseButton.Location = new System.Drawing.Point(583, 63);
            this.BrowseButton.Name = "BrowseButton";
            this.BrowseButton.Size = new System.Drawing.Size(75, 23);
            this.BrowseButton.TabIndex = 9;
            this.BrowseButton.Text = "Browse...";
            this.BrowseButton.UseVisualStyleBackColor = true;
            this.BrowseButton.Click += new System.EventHandler(this.BrowseButton_Click);
            // 
            // msLabel2
            // 
            this.msLabel2.AutoSize = true;
            this.msLabel2.Location = new System.Drawing.Point(583, 44);
            this.msLabel2.Name = "msLabel2";
            this.msLabel2.Size = new System.Drawing.Size(20, 13);
            this.msLabel2.TabIndex = 19;
            this.msLabel2.Text = "ms";
            // 
            // msLabel
            // 
            this.msLabel.AutoSize = true;
            this.msLabel.Location = new System.Drawing.Point(238, 44);
            this.msLabel.Name = "msLabel";
            this.msLabel.Size = new System.Drawing.Size(20, 13);
            this.msLabel.TabIndex = 18;
            this.msLabel.Text = "ms";
            // 
            // dBmLabel
            // 
            this.dBmLabel.AutoSize = true;
            this.dBmLabel.Location = new System.Drawing.Point(583, 20);
            this.dBmLabel.Name = "dBmLabel";
            this.dBmLabel.Size = new System.Drawing.Size(28, 13);
            this.dBmLabel.TabIndex = 17;
            this.dBmLabel.Text = "dBm";
            // 
            // CarrFreTxt
            // 
            this.CarrFreTxt.Location = new System.Drawing.Point(118, 17);
            this.CarrFreTxt.Name = "CarrFreTxt";
            this.CarrFreTxt.Size = new System.Drawing.Size(114, 20);
            this.CarrFreTxt.TabIndex = 2;
            this.CarrFreTxt.TextChanged += new System.EventHandler(this.CarrFreTxt_TextChanged);
            // 
            // CarrFreComboBox
            // 
            this.CarrFreComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CarrFreComboBox.FormattingEnabled = true;
            this.CarrFreComboBox.Items.AddRange(new object[] {
            "Hz",
            "KHz",
            "MHz",
            "GHz",
            "THz"});
            this.CarrFreComboBox.Location = new System.Drawing.Point(238, 16);
            this.CarrFreComboBox.Name = "CarrFreComboBox";
            this.CarrFreComboBox.Size = new System.Drawing.Size(48, 21);
            this.CarrFreComboBox.TabIndex = 3;
            this.CarrFreComboBox.SelectedIndexChanged += new System.EventHandler(this.CarrFreComboBox_SelectedIndexChanged);
            // 
            // NonlinOrderTxt
            // 
            this.NonlinOrderTxt.Location = new System.Drawing.Point(463, 89);
            this.NonlinOrderTxt.Name = "NonlinOrderTxt";
            this.NonlinOrderTxt.Size = new System.Drawing.Size(114, 20);
            this.NonlinOrderTxt.TabIndex = 11;
            this.NonlinOrderTxt.TextChanged += new System.EventHandler(this.NonlinOrderTxt_TextChanged);
            // 
            // VSASetTxt
            // 
            this.VSASetTxt.Location = new System.Drawing.Point(463, 65);
            this.VSASetTxt.Name = "VSASetTxt";
            this.VSASetTxt.Size = new System.Drawing.Size(114, 20);
            this.VSASetTxt.TabIndex = 8;
            this.VSASetTxt.TextChanged += new System.EventHandler(this.VSASetTxt_TextChanged);
            // 
            // TimeStopTxt
            // 
            this.TimeStopTxt.Location = new System.Drawing.Point(463, 41);
            this.TimeStopTxt.Name = "TimeStopTxt";
            this.TimeStopTxt.Size = new System.Drawing.Size(114, 20);
            this.TimeStopTxt.TabIndex = 6;
            this.TimeStopTxt.TextChanged += new System.EventHandler(this.TimeStopTxt_TextChanged);
            // 
            // RFPowerTxt
            // 
            this.RFPowerTxt.Location = new System.Drawing.Point(463, 17);
            this.RFPowerTxt.Name = "RFPowerTxt";
            this.RFPowerTxt.Size = new System.Drawing.Size(114, 20);
            this.RFPowerTxt.TabIndex = 4;
            this.RFPowerTxt.TextChanged += new System.EventHandler(this.RFPwerTxt_TextChanged);
            // 
            // NonlinOrderLabel
            // 
            this.NonlinOrderLabel.AutoSize = true;
            this.NonlinOrderLabel.Location = new System.Drawing.Point(350, 92);
            this.NonlinOrderLabel.Name = "NonlinOrderLabel";
            this.NonlinOrderLabel.Size = new System.Drawing.Size(81, 13);
            this.NonlinOrderLabel.TabIndex = 11;
            this.NonlinOrderLabel.Text = "Nonlinear Order";
            // 
            // VSASetLabel
            // 
            this.VSASetLabel.AutoSize = true;
            this.VSASetLabel.Location = new System.Drawing.Point(350, 68);
            this.VSASetLabel.Name = "VSASetLabel";
            this.VSASetLabel.Size = new System.Drawing.Size(78, 13);
            this.VSASetLabel.TabIndex = 10;
            this.VSASetLabel.Text = "VSA Setup File";
            // 
            // TimeStopLabel
            // 
            this.TimeStopLabel.AutoSize = true;
            this.TimeStopLabel.Location = new System.Drawing.Point(350, 44);
            this.TimeStopLabel.Name = "TimeStopLabel";
            this.TimeStopLabel.Size = new System.Drawing.Size(55, 13);
            this.TimeStopLabel.TabIndex = 9;
            this.TimeStopLabel.Text = "Time Stop";
            // 
            // RFPowerLabel
            // 
            this.RFPowerLabel.AutoSize = true;
            this.RFPowerLabel.Location = new System.Drawing.Point(350, 20);
            this.RFPowerLabel.Name = "RFPowerLabel";
            this.RFPowerLabel.Size = new System.Drawing.Size(54, 13);
            this.RFPowerLabel.TabIndex = 8;
            this.RFPowerLabel.Text = "RF Power";
            // 
            // MemOrderTxt
            // 
            this.MemOrderTxt.Location = new System.Drawing.Point(118, 89);
            this.MemOrderTxt.Name = "MemOrderTxt";
            this.MemOrderTxt.Size = new System.Drawing.Size(114, 20);
            this.MemOrderTxt.TabIndex = 10;
            this.MemOrderTxt.TextChanged += new System.EventHandler(this.MemOrderTxt_TextChanged);
            // 
            // InstrAddrTxt
            // 
            this.InstrAddrTxt.Location = new System.Drawing.Point(118, 65);
            this.InstrAddrTxt.Name = "InstrAddrTxt";
            this.InstrAddrTxt.Size = new System.Drawing.Size(114, 20);
            this.InstrAddrTxt.TabIndex = 7;
            this.InstrAddrTxt.TextChanged += new System.EventHandler(this.InstrAddrTxt_TextChanged);
            // 
            // TimeStartTxt
            // 
            this.TimeStartTxt.Location = new System.Drawing.Point(118, 41);
            this.TimeStartTxt.Name = "TimeStartTxt";
            this.TimeStartTxt.Size = new System.Drawing.Size(114, 20);
            this.TimeStartTxt.TabIndex = 5;
            this.TimeStartTxt.TextChanged += new System.EventHandler(this.TimeStartTxt_TextChanged);
            // 
            // MemOrderLabel
            // 
            this.MemOrderLabel.AutoSize = true;
            this.MemOrderLabel.Location = new System.Drawing.Point(6, 92);
            this.MemOrderLabel.Name = "MemOrderLabel";
            this.MemOrderLabel.Size = new System.Drawing.Size(73, 13);
            this.MemOrderLabel.TabIndex = 3;
            this.MemOrderLabel.Text = "Memory Order";
            // 
            // InstrAddrLabel
            // 
            this.InstrAddrLabel.AutoSize = true;
            this.InstrAddrLabel.Location = new System.Drawing.Point(6, 68);
            this.InstrAddrLabel.Name = "InstrAddrLabel";
            this.InstrAddrLabel.Size = new System.Drawing.Size(97, 13);
            this.InstrAddrLabel.TabIndex = 2;
            this.InstrAddrLabel.Text = "Instrument Address";
            // 
            // TimeStartLabel
            // 
            this.TimeStartLabel.AutoSize = true;
            this.TimeStartLabel.Location = new System.Drawing.Point(6, 44);
            this.TimeStartLabel.Name = "TimeStartLabel";
            this.TimeStartLabel.Size = new System.Drawing.Size(55, 13);
            this.TimeStartLabel.TabIndex = 1;
            this.TimeStartLabel.Text = "Time Start";
            // 
            // CarrFreqLabel
            // 
            this.CarrFreqLabel.AutoSize = true;
            this.CarrFreqLabel.Location = new System.Drawing.Point(6, 20);
            this.CarrFreqLabel.Name = "CarrFreqLabel";
            this.CarrFreqLabel.Size = new System.Drawing.Size(90, 13);
            this.CarrFreqLabel.TabIndex = 0;
            this.CarrFreqLabel.Text = "Carrier Frequency";
            // 
            // StartButton
            // 
            this.StartButton.Location = new System.Drawing.Point(12, 209);
            this.StartButton.Name = "StartButton";
            this.StartButton.Size = new System.Drawing.Size(137, 23);
            this.StartButton.TabIndex = 12;
            this.StartButton.Text = "Start Running Analysis";
            this.StartButton.UseVisualStyleBackColor = true;
            this.StartButton.Click += new System.EventHandler(this.StartButton_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.DPDOutPowerLabel);
            this.groupBox2.Controls.Add(this.EVMLabel);
            this.groupBox2.Controls.Add(this.ACPLabel);
            this.groupBox2.Controls.Add(this.ACPdataGridView2);
            this.groupBox2.Controls.Add(this.EVMdataGridView);
            this.groupBox2.Controls.Add(this.ACPdataGridView);
            this.groupBox2.Controls.Add(this.chart1);
            this.groupBox2.Controls.Add(this.DPDOutTxt);
            this.groupBox2.Controls.Add(this.dBmLabel2);
            this.groupBox2.Controls.Add(this.SpectrumButton);
            this.groupBox2.Location = new System.Drawing.Point(12, 238);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(698, 312);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Results";
            // 
            // DPDOutPowerLabel
            // 
            this.DPDOutPowerLabel.AutoSize = true;
            this.DPDOutPowerLabel.Location = new System.Drawing.Point(350, 261);
            this.DPDOutPowerLabel.Name = "DPDOutPowerLabel";
            this.DPDOutPowerLabel.Size = new System.Drawing.Size(115, 13);
            this.DPDOutPowerLabel.TabIndex = 12;
            this.DPDOutPowerLabel.Text = "DPD-PA Output Power";
            // 
            // EVMLabel
            // 
            this.EVMLabel.AutoSize = true;
            this.EVMLabel.Location = new System.Drawing.Point(350, 149);
            this.EVMLabel.Name = "EVMLabel";
            this.EVMLabel.Size = new System.Drawing.Size(30, 13);
            this.EVMLabel.TabIndex = 11;
            this.EVMLabel.Text = "EVM";
            // 
            // ACPLabel
            // 
            this.ACPLabel.AutoSize = true;
            this.ACPLabel.Location = new System.Drawing.Point(350, 20);
            this.ACPLabel.Name = "ACPLabel";
            this.ACPLabel.Size = new System.Drawing.Size(28, 13);
            this.ACPLabel.TabIndex = 10;
            this.ACPLabel.Text = "ACP";
            // 
            // ACPdataGridView2
            // 
            this.ACPdataGridView2.AllowUserToResizeRows = false;
            this.ACPdataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ACPdataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ACP_Upper_Orig,
            this.ACP_Upper_wDPD,
            this.ACP_Upper_woDPD});
            this.ACPdataGridView2.Location = new System.Drawing.Point(353, 82);
            this.ACPdataGridView2.Name = "ACPdataGridView2";
            this.ACPdataGridView2.RowHeadersVisible = false;
            this.ACPdataGridView2.RowTemplate.ReadOnly = true;
            this.ACPdataGridView2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ACPdataGridView2.Size = new System.Drawing.Size(333, 44);
            this.ACPdataGridView2.TabIndex = 9;
            this.ACPdataGridView2.TabStop = false;
            // 
            // ACP_Upper_Orig
            // 
            this.ACP_Upper_Orig.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ACP_Upper_Orig.HeaderText = "ACP_Upper_Orig";
            this.ACP_Upper_Orig.Name = "ACP_Upper_Orig";
            this.ACP_Upper_Orig.ReadOnly = true;
            this.ACP_Upper_Orig.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ACP_Upper_Orig.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ACP_Upper_wDPD
            // 
            this.ACP_Upper_wDPD.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ACP_Upper_wDPD.HeaderText = "ACP_Upper_wDPD";
            this.ACP_Upper_wDPD.Name = "ACP_Upper_wDPD";
            this.ACP_Upper_wDPD.ReadOnly = true;
            this.ACP_Upper_wDPD.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ACP_Upper_wDPD.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ACP_Upper_woDPD
            // 
            this.ACP_Upper_woDPD.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ACP_Upper_woDPD.HeaderText = "ACP_Upper_woDPD";
            this.ACP_Upper_woDPD.Name = "ACP_Upper_woDPD";
            this.ACP_Upper_woDPD.ReadOnly = true;
            this.ACP_Upper_woDPD.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ACP_Upper_woDPD.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // EVMdataGridView
            // 
            this.EVMdataGridView.AllowUserToResizeRows = false;
            this.EVMdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.EVMdataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EVM_Orig,
            this.EVM_wDPD,
            this.EVM_woDPD});
            this.EVMdataGridView.Location = new System.Drawing.Point(353, 173);
            this.EVMdataGridView.Name = "EVMdataGridView";
            this.EVMdataGridView.RowHeadersVisible = false;
            this.EVMdataGridView.Size = new System.Drawing.Size(333, 45);
            this.EVMdataGridView.TabIndex = 8;
            this.EVMdataGridView.TabStop = false;
            // 
            // EVM_Orig
            // 
            this.EVM_Orig.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.EVM_Orig.HeaderText = "EVM_Orig";
            this.EVM_Orig.Name = "EVM_Orig";
            this.EVM_Orig.ReadOnly = true;
            this.EVM_Orig.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.EVM_Orig.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // EVM_wDPD
            // 
            this.EVM_wDPD.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.EVM_wDPD.HeaderText = "EVM_wDPD";
            this.EVM_wDPD.Name = "EVM_wDPD";
            this.EVM_wDPD.ReadOnly = true;
            this.EVM_wDPD.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.EVM_wDPD.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // EVM_woDPD
            // 
            this.EVM_woDPD.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.EVM_woDPD.HeaderText = "EVM_woDPD";
            this.EVM_woDPD.Name = "EVM_woDPD";
            this.EVM_woDPD.ReadOnly = true;
            this.EVM_woDPD.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.EVM_woDPD.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ACPdataGridView
            // 
            this.ACPdataGridView.AllowUserToResizeRows = false;
            this.ACPdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ACPdataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ACP_Lower_Orig,
            this.ACP_Lower_wDPD,
            this.ACP_Lower_woDPD});
            this.ACPdataGridView.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ACPdataGridView.Location = new System.Drawing.Point(353, 40);
            this.ACPdataGridView.Name = "ACPdataGridView";
            this.ACPdataGridView.RowHeadersVisible = false;
            this.ACPdataGridView.RowTemplate.ReadOnly = true;
            this.ACPdataGridView.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ACPdataGridView.Size = new System.Drawing.Size(333, 44);
            this.ACPdataGridView.TabIndex = 0;
            this.ACPdataGridView.TabStop = false;
            // 
            // ACP_Lower_Orig
            // 
            this.ACP_Lower_Orig.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ACP_Lower_Orig.HeaderText = "ACP_Lower_Orig";
            this.ACP_Lower_Orig.Name = "ACP_Lower_Orig";
            this.ACP_Lower_Orig.ReadOnly = true;
            this.ACP_Lower_Orig.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ACP_Lower_Orig.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ACP_Lower_wDPD
            // 
            this.ACP_Lower_wDPD.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ACP_Lower_wDPD.HeaderText = "ACP_Lower_wDPD";
            this.ACP_Lower_wDPD.Name = "ACP_Lower_wDPD";
            this.ACP_Lower_wDPD.ReadOnly = true;
            this.ACP_Lower_wDPD.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ACP_Lower_wDPD.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ACP_Lower_woDPD
            // 
            this.ACP_Lower_woDPD.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ACP_Lower_woDPD.HeaderText = "ACP_Lower_woDPD";
            this.ACP_Lower_woDPD.Name = "ACP_Lower_woDPD";
            this.ACP_Lower_woDPD.ReadOnly = true;
            this.ACP_Lower_woDPD.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ACP_Lower_woDPD.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // chart1
            // 
            chartArea4.AxisX.Title = "Frequency (GHz)";
            chartArea4.AxisX.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea4.AxisY.Title = "Spectrum (dBm)";
            chartArea4.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea4.BackColor = System.Drawing.Color.White;
            chartArea4.CursorX.IsUserEnabled = true;
            chartArea4.CursorX.IsUserSelectionEnabled = true;
            chartArea4.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea4);
            legend4.BackColor = System.Drawing.Color.White;
            legend4.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;
            legend4.Name = "Legend1";
            this.chart1.Legends.Add(legend4);
            this.chart1.Location = new System.Drawing.Point(9, 20);
            this.chart1.Name = "chart1";
            series10.ChartArea = "ChartArea1";
            series10.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            series10.Color = System.Drawing.Color.Lime;
            series10.CustomProperties = "IsXAxisQuantitative=False";
            series10.IsXValueIndexed = true;
            series10.Legend = "Legend1";
            series10.Name = "Origin Signal";
            series11.ChartArea = "ChartArea1";
            series11.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            series11.Color = System.Drawing.Color.Blue;
            series11.CustomProperties = "IsXAxisQuantitative=False";
            series11.IsXValueIndexed = true;
            series11.Legend = "Legend1";
            series11.Name = "PA Output w/o DPD";
            series12.ChartArea = "ChartArea1";
            series12.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            series12.Color = System.Drawing.Color.Red;
            series12.CustomProperties = "IsXAxisQuantitative=False";
            series12.IsXValueIndexed = true;
            series12.Legend = "Legend1";
            series12.Name = "DPD-PA Output";
            this.chart1.Series.Add(series10);
            this.chart1.Series.Add(series11);
            this.chart1.Series.Add(series12);
            this.chart1.Size = new System.Drawing.Size(322, 254);
            this.chart1.TabIndex = 6;
            this.chart1.Text = "Spectrum";
            title4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            title4.Name = "Spectrum";
            title4.Text = "Spectrum";
            this.chart1.Titles.Add(title4);
            // 
            // DPDOutTxt
            // 
            this.DPDOutTxt.BackColor = System.Drawing.SystemColors.Window;
            this.DPDOutTxt.Location = new System.Drawing.Point(471, 258);
            this.DPDOutTxt.Name = "DPDOutTxt";
            this.DPDOutTxt.ReadOnly = true;
            this.DPDOutTxt.Size = new System.Drawing.Size(114, 20);
            this.DPDOutTxt.TabIndex = 4;
            this.DPDOutTxt.TabStop = false;
            // 
            // dBmLabel2
            // 
            this.dBmLabel2.AutoSize = true;
            this.dBmLabel2.Location = new System.Drawing.Point(591, 261);
            this.dBmLabel2.Name = "dBmLabel2";
            this.dBmLabel2.Size = new System.Drawing.Size(28, 13);
            this.dBmLabel2.TabIndex = 5;
            this.dBmLabel2.Text = "dBm";
            // 
            // SpectrumButton
            // 
            this.SpectrumButton.Location = new System.Drawing.Point(9, 280);
            this.SpectrumButton.Name = "SpectrumButton";
            this.SpectrumButton.Size = new System.Drawing.Size(120, 23);
            this.SpectrumButton.TabIndex = 13;
            this.SpectrumButton.Text = "View Large Spectrum";
            this.SpectrumButton.UseVisualStyleBackColor = true;
            this.SpectrumButton.Click += new System.EventHandler(this.SpectrumButton_Click);
            // 
            // LoadwsvLabel
            // 
            this.LoadwsvLabel.AutoSize = true;
            this.LoadwsvLabel.Location = new System.Drawing.Point(18, 40);
            this.LoadwsvLabel.Name = "LoadwsvLabel";
            this.LoadwsvLabel.Size = new System.Drawing.Size(108, 13);
            this.LoadwsvLabel.TabIndex = 4;
            this.LoadwsvLabel.Text = "Load Workspace File";
            // 
            // ChooseFileButton
            // 
            this.ChooseFileButton.Location = new System.Drawing.Point(130, 35);
            this.ChooseFileButton.Name = "ChooseFileButton";
            this.ChooseFileButton.Size = new System.Drawing.Size(114, 23);
            this.ChooseFileButton.TabIndex = 1;
            this.ChooseFileButton.Text = "Browse...";
            this.ChooseFileButton.UseVisualStyleBackColor = true;
            this.ChooseFileButton.Click += new System.EventHandler(this.ChooseFileButton_Click);
            // 
            // LoadingLabel
            // 
            this.LoadingLabel.AutoSize = true;
            this.LoadingLabel.Location = new System.Drawing.Point(247, 40);
            this.LoadingLabel.Name = "LoadingLabel";
            this.LoadingLabel.Size = new System.Drawing.Size(175, 13);
            this.LoadingLabel.TabIndex = 6;
            this.LoadingLabel.Text = "Loading... Please wait for a moment";
            this.LoadingLabel.Visible = false;
            // 
            // RunningLabel
            // 
            this.RunningLabel.AutoSize = true;
            this.RunningLabel.Location = new System.Drawing.Point(172, 214);
            this.RunningLabel.Name = "RunningLabel";
            this.RunningLabel.Size = new System.Drawing.Size(218, 13);
            this.RunningLabel.TabIndex = 14;
            this.RunningLabel.Text = "Running Analysis... Please wait for a moment";
            this.RunningLabel.Visible = false;
            // 
            // PathLabel
            // 
            this.PathLabel.Enabled = false;
            this.PathLabel.Location = new System.Drawing.Point(245, 40);
            this.PathLabel.Name = "PathLabel";
            this.PathLabel.Size = new System.Drawing.Size(384, 47);
            this.PathLabel.TabIndex = 8;
            this.PathLabel.Visible = false;
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(635, 35);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(75, 23);
            this.SaveButton.TabIndex = 17;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // SaveAsButton
            // 
            this.SaveAsButton.Location = new System.Drawing.Point(635, 64);
            this.SaveAsButton.Name = "SaveAsButton";
            this.SaveAsButton.Size = new System.Drawing.Size(75, 23);
            this.SaveAsButton.TabIndex = 18;
            this.SaveAsButton.Text = "Save as...";
            this.SaveAsButton.UseVisualStyleBackColor = true;
            this.SaveAsButton.Click += new System.EventHandler(this.SaveAsButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.ClientSize = new System.Drawing.Size(722, 562);
            this.Controls.Add(this.SaveAsButton);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.PathLabel);
            this.Controls.Add(this.RunningLabel);
            this.Controls.Add(this.LoadingLabel);
            this.Controls.Add(this.ChooseFileButton);
            this.Controls.Add(this.LoadwsvLabel);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.StartButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.DPDDemoLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DPD";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_Closed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ACPdataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EVMdataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ACPdataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label DPDDemoLabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox NonlinOrderTxt;
        private System.Windows.Forms.TextBox VSASetTxt;
        private System.Windows.Forms.TextBox TimeStopTxt;
        private System.Windows.Forms.TextBox RFPowerTxt;
        private System.Windows.Forms.Label NonlinOrderLabel;
        private System.Windows.Forms.Label VSASetLabel;
        private System.Windows.Forms.Label TimeStopLabel;
        private System.Windows.Forms.Label RFPowerLabel;
        private System.Windows.Forms.TextBox MemOrderTxt;
        private System.Windows.Forms.TextBox InstrAddrTxt;
        private System.Windows.Forms.TextBox TimeStartTxt;
        private System.Windows.Forms.TextBox CarrFreTxt;
        private System.Windows.Forms.Label MemOrderLabel;
        private System.Windows.Forms.Label InstrAddrLabel;
        private System.Windows.Forms.Label TimeStartLabel;
        private System.Windows.Forms.Label CarrFreqLabel;
        private System.Windows.Forms.Button StartButton;
        private System.Windows.Forms.Label msLabel2;
        private System.Windows.Forms.Label msLabel;
        private System.Windows.Forms.Label dBmLabel;
        private System.Windows.Forms.ComboBox CarrFreComboBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label dBmLabel2;
        private System.Windows.Forms.TextBox DPDOutTxt;
        private System.Windows.Forms.Button SpectrumButton;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataGridView ACPdataGridView;
        private System.Windows.Forms.DataGridView EVMdataGridView;
        private System.Windows.Forms.DataGridView ACPdataGridView2;
        private System.Windows.Forms.Button BrowseButton;
        private System.Windows.Forms.Label LoadwsvLabel;
        private System.Windows.Forms.Button ChooseFileButton;
        private System.Windows.Forms.Label DPDOutPowerLabel;
        private System.Windows.Forms.Label EVMLabel;
        private System.Windows.Forms.Label ACPLabel;
        private System.Windows.Forms.Label LoadingLabel;
        private System.Windows.Forms.Label RunningLabel;
        private System.Windows.Forms.Label PathLabel;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACP_Lower_Orig;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACP_Lower_wDPD;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACP_Lower_woDPD;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACP_Upper_Orig;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACP_Upper_wDPD;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACP_Upper_woDPD;
        private System.Windows.Forms.DataGridViewTextBoxColumn EVM_Orig;
        private System.Windows.Forms.DataGridViewTextBoxColumn EVM_wDPD;
        private System.Windows.Forms.DataGridViewTextBoxColumn EVM_woDPD;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button SaveAsButton;
    }
}

