﻿// Copyright 2014 Keysight Technologies, Inc , Keysight Confidential
using System;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace DPD_SFP
{
    public partial class MainForm : Form
    {
        Dpd _dpdApplication;

        public MainForm()
        {
            InitializeComponent();
            DisableComponent();
        }

        private void InitializeTextBox()
        {
            IniCarrFreTxt();
            IniRfPowerTxt();
            IniTimeStartTxt();
            IniTimeStopTxt();
            IniInstrAddrTxt();
            IniVsaSetTxt();
            IniMemOrderTxt();
            IniNonlinOrderTxt();
        }

        private void DisableComponent()
        {
            groupBox1.Enabled = false;
            groupBox2.Enabled = false;
            StartButton.Enabled = false;
            SaveButton.Enabled = false;
            SaveAsButton.Enabled = false;
            EVMdataGridView.Visible = false;
            ACPdataGridView.Visible = false;
            ACPdataGridView2.Visible = false;
            chart1.Visible = false;
        }

        private void EnableComponent()
        {
            groupBox1.Enabled = true;
            groupBox2.Enabled = true;
            StartButton.Enabled = true;
            SaveButton.Enabled = true;
            SaveAsButton.Enabled = true;
            EVMdataGridView.Visible = true;
            ACPdataGridView.Visible = true;
            ACPdataGridView2.Visible = true;
            chart1.Visible = true;
        }

        private void IniNonlinOrderTxt()
        {
            NonlinOrderTxt.Text = _dpdApplication.GetNonlinearOrder().ToString(CultureInfo.InvariantCulture);
        }

        private void IniMemOrderTxt()
        {
            MemOrderTxt.Text = _dpdApplication.GetMemOrder().ToString(CultureInfo.InvariantCulture);
        }

        private void IniVsaSetTxt()
        {
            VSASetTxt.Text = _dpdApplication.GetVsaSetFile();
        }

        private void IniInstrAddrTxt()
        {
            InstrAddrTxt.Text = _dpdApplication.GetPrimAddress();
        }

        private void IniTimeStopTxt()
        {
            TimeStopTxt.Text = _dpdApplication.GetTimeStop().ToString(CultureInfo.InvariantCulture);
        }

        private void IniTimeStartTxt()
        {
            TimeStartTxt.Text = _dpdApplication.GetTimeStart().ToString(CultureInfo.InvariantCulture);
        }

        private void IniRfPowerTxt()
        {
            RFPowerTxt.Text = _dpdApplication.GetOriRfPower().ToString(CultureInfo.InvariantCulture);
        }

        private void IniCarrFreTxt()
        {
            var freq = (long)_dpdApplication.GetCarrFreq();
            int len = freq.ToString(CultureInfo.InvariantCulture).Length;
            if (len < 4)
            {
                CarrFreTxt.Text = freq.ToString(CultureInfo.InvariantCulture);
                CarrFreComboBox.Text = @"Hz";
            }
            else if (len < 7)
            {
                CarrFreTxt.Text = (freq / 1.0e3).ToString(CultureInfo.InvariantCulture);
                CarrFreComboBox.Text = @"KHz";
            }
            else if (len < 10)
            {
                CarrFreTxt.Text = (freq / 1.0e6).ToString(CultureInfo.InvariantCulture);
                CarrFreComboBox.Text = @"MHz";
            }
            else if (len < 13)
            {
                CarrFreTxt.Text = (freq / 1.0e9).ToString(CultureInfo.InvariantCulture);
                CarrFreComboBox.Text = @"GHz";
            }
            else
            {
                CarrFreTxt.Text = (freq / 1.0e12).ToString(CultureInfo.InvariantCulture);
                CarrFreComboBox.Text = @"THz";
            }
        }

        private void CarrFreTxt_TextChanged(object sender, EventArgs e)
        {
            bool a = Regex.IsMatch(CarrFreTxt.Text, @"^[+]?\d*[.]?\d*$");
            if (a)
            {
                if (CarrFreTxt.Text != "")
                {
                    ResetCarrFre();
                }
            }
            else
            {
                var warn = new Warn();
                warn.Label("Carrier Frequency is not a valid positive number!");
                warn.ShowDialog();
            }
        }

        private void ResetCarrFre()
        {
            if (CarrFreTxt.Text != "")
            {
                double carrfre = double.Parse(CarrFreTxt.Text);
                int index = CarrFreComboBox.SelectedIndex;
                switch (index)
                {
                    case 0:
                        _dpdApplication.SetFCarrier(carrfre);
                        break;
                    case 1:
                        carrfre *= 1000;
                        _dpdApplication.SetFCarrier(carrfre);
                        break;
                    case 2:
                        carrfre *= 1e6;
                        _dpdApplication.SetFCarrier(carrfre);
                        break;
                    case 3:
                        carrfre *= 1e9;
                        _dpdApplication.SetFCarrier(carrfre);
                        break;
                    case 4:
                        carrfre *= 1e12;
                        _dpdApplication.SetFCarrier(carrfre);
                        break;
                }
            }
        }

        private void CarrFreComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetCarrFre();
        }

        private void RFPwerTxt_TextChanged(object sender, EventArgs e)
        {
            bool a = Regex.IsMatch(RFPowerTxt.Text, @"^[+-]?\d*[.]?\d*$");
            if (a)
            {
                if (RFPowerTxt.Text != "" && RFPowerTxt.Text != @"-")
                {
                    double rfpower = double.Parse(RFPowerTxt.Text);
                    _dpdApplication.SetOriRfPower(rfpower);
                }
            }
            else
            {
                var warn = new Warn();
                warn.Label("RF Power is not a valid number!");
                warn.ShowDialog();
            }
        }

        private void TimeStartTxt_TextChanged(object sender, EventArgs e)
        {
            bool a = Regex.IsMatch(TimeStartTxt.Text, @"^[+]?\d*[.]?\d*$");
            if (a)
            {
                if (TimeStartTxt.Text != "")
                {
                    double timestart = double.Parse(TimeStartTxt.Text);
                    _dpdApplication.SetTimeStart(timestart);
                }
            }
            else
            {
                var warn = new Warn();
                warn.Label("Time Start is not a valid non-negative number!");
                warn.ShowDialog();
            }
        }

        private void TimeStopTxt_TextChanged(object sender, EventArgs e)
        {
            bool a = Regex.IsMatch(TimeStopTxt.Text, @"^[+]?\d*[.]?\d*$");
            if (a)
            {
                if (TimeStopTxt.Text != "")
                {
                    double timestop = double.Parse(TimeStopTxt.Text);
                    _dpdApplication.SetTimeStop(timestop);
                }
            }
            else
            {
                var warn = new Warn();
                warn.Label("Time Stop is not a valid non-negative number!");
                warn.ShowDialog();
            }
        }

        private void MemOrderTxt_TextChanged(object sender, EventArgs e)
        {
            bool a = Regex.IsMatch(MemOrderTxt.Text, @"^[+]?\d*$");
            if (a)
            {
                if (MemOrderTxt.Text != "")
                {
                    double memorder = double.Parse(MemOrderTxt.Text);
                    _dpdApplication.SetMemoryOrder(memorder);
                }
            }
            else
            {
                var warn = new Warn();
                warn.Label("Memory Order is not a valid non-negative integer!");
                warn.ShowDialog();
            }
        }

        private void NonlinOrderTxt_TextChanged(object sender, EventArgs e)
        {
            bool a = Regex.IsMatch(NonlinOrderTxt.Text, @"^[+]?\d*$");
            if (a)
            {
                if (NonlinOrderTxt.Text != "")
                {
                    double nonlinearorder = double.Parse(NonlinOrderTxt.Text);
                    _dpdApplication.SetNonlinearOrder(nonlinearorder);
                }
            }
            else
            {
                var warn = new Warn();
                warn.Label("Nonlinear Order is not a valid non-negative integer!");
                warn.ShowDialog();
            }
        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            ClearResult();
            DisableComponent();
            LoadwsvLabel.Enabled = false;
            ChooseFileButton.Enabled = false;
            RunningLabel.Visible = true;
            StartRunAnalysis();
            RunningLabel.Visible = false;
            LoadwsvLabel.Enabled = true;
            ChooseFileButton.Enabled = true;
            EnableComponent();
            Drawchart1();
            AcpResult();
            EvmResult();
            DpdResult();
        }

        private void StartRunAnalysis()
        {
            _dpdApplication.RunCreateDpdStimulusAnalysis();
            _dpdApplication.RunAdjustRfPowerAnalysis();
            _dpdApplication.RunCaptureDutResponseAnalysis();
            _dpdApplication.RunDutModelExtractionAnalysis();
            _dpdApplication.RunPowerAlignmentAnalysis();
            _dpdApplication.RunApply_DPDAnalysis();
            _dpdApplication.RunCaptureDPD_PAOutputDataAnalysis();
            _dpdApplication.RunSpectrumPlotAnalysis();
        }

        private void SpectrumButton_Click(object sender, EventArgs e)
        {
            double[] origFreq = _dpdApplication.GetOrigFreq();
            double[] origSig = _dpdApplication.GetOrigSig();
            double[] paOutFreq = _dpdApplication.GetDpdPaOutFreq();
            double[] paOutPower = _dpdApplication.GetDpdPaOutPower();
            double[] dpdpaOutFreq = _dpdApplication.GetStep2PaOutFreq();
            double[] dpdpaOutPower = _dpdApplication.GetStep2PaOutPower();
            var form = new Spectrum();
            if (origSig != null)
            {
                form.DrawOrigSig(origFreq, origSig);
            }
            if (paOutPower != null)
            {
                form.DrawDpdPaOutPower(paOutFreq, paOutPower);
            }
            if (dpdpaOutPower != null)
            {
                form.DrawPaOutPower(dpdpaOutFreq, dpdpaOutPower);
            }
            form.ShowDialog();
        }

        private void DrawDpdPaOutPower(double[] dpdPaOutFreq, double[] dpdPaOutPower)
        {
            for (int i = 0; i != dpdPaOutFreq.Length; ++i)
            {
                chart1.Series["DPD-PA Output"].Points.AddXY(dpdPaOutFreq[i] / 1e9, 10 * Math.Log(dpdPaOutPower[i] * 1e3, 10));
            }
        }

        private void DrawPaOutPower(double[] paOutFreq, double[] paOutPower)
        {
            for (int i = 0; i != paOutFreq.Length; ++i)
            {
                chart1.Series["PA Output w/o DPD"].Points.AddXY(paOutFreq[i] / 1e9, 10 * Math.Log(paOutPower[i] * 1e3, 10));
            }
        }

        private void DrawOrigSig(double[] origFreq, double[] origSig)
        {
            for (int i = 0; i != origFreq.Length; ++i)
            {
                chart1.Series["Origin Signal"].Points.AddXY(origFreq[i] / 1e9, 10 * Math.Log(origSig[i] * 1e3, 10));
            }
        }

        private void ClearResult()
        {
            chart1.Series["DPD-PA Output"].Points.Clear();
            chart1.Series["PA Output w/o DPD"].Points.Clear();
            chart1.Series["Origin Signal"].Points.Clear();

            ACPdataGridView["ACP_Lower_Orig", 0].Value = null;
            ACPdataGridView["ACP_Lower_wDPD", 0].Value = null;
            ACPdataGridView["ACP_Lower_woDPD", 0].Value = null;
            ACPdataGridView2["ACP_Upper_Orig", 0].Value = null;
            ACPdataGridView2["ACP_Upper_wDPD", 0].Value = null;
            ACPdataGridView2["ACP_Upper_woDPD", 0].Value = null;

            EVMdataGridView["EVM_Orig", 0].Value = null;
            EVMdataGridView["EVM_wDPD", 0].Value = null;
            EVMdataGridView["EVM_woDPD", 0].Value = null;

            DPDOutTxt.Text = null;
        }

        private void AcpResult()
        {
            _dpdApplication.RunCalEquationAcp();
            double acpLowerOrig = _dpdApplication.GetAcpLowerOrig();
            double acpLowerWdpd = _dpdApplication.GetAcpLowerWdpd();
            double acpLowerWodpd = _dpdApplication.GetAcpLowerWodpd();
            double acpUpperOrig = _dpdApplication.GetAcpUpperOrig();
            double acpUpperWdpd = _dpdApplication.GetAcpUpperWdpd();
            double acpUpperWodpd = _dpdApplication.GetAcpUpperWodpd();
            ACPdataGridView["ACP_Lower_Orig", 0].Value = acpLowerOrig.ToString("#0.000");
            ACPdataGridView["ACP_Lower_wDPD", 0].Value = acpLowerWdpd.ToString("#0.000");
            ACPdataGridView["ACP_Lower_woDPD", 0].Value = acpLowerWodpd.ToString("#0.000");
            ACPdataGridView2["ACP_Upper_Orig", 0].Value = acpUpperOrig.ToString("#0.000");
            ACPdataGridView2["ACP_Upper_wDPD", 0].Value = acpUpperWdpd.ToString("#0.000");
            ACPdataGridView2["ACP_Upper_woDPD", 0].Value = acpUpperWodpd.ToString("#0.000");
        }

        private void EvmResult()
        {
            _dpdApplication.RunCalEquationEvm();
            double evmOrig = _dpdApplication.GetEvmOrig();
            double evmwdpd = _dpdApplication.GetEvmwdpd();
            double evmwodpd = _dpdApplication.GetEvmwodpd();
            EVMdataGridView["EVM_Orig", 0].Value = evmOrig.ToString("#0.000");
            EVMdataGridView["EVM_wDPD", 0].Value = evmwdpd.ToString("#0.000");
            EVMdataGridView["EVM_woDPD", 0].Value = evmwodpd.ToString("#0.000");
        }

        private void DpdResult()
        {
            _dpdApplication.RunCalEquationDPD_PAPower();
            DPDOutTxt.Text = _dpdApplication.GetDpdOutputPower().ToString("#0.000");
        }

        private void Drawchart1()
        {
            chart1.Series["DPD-PA Output"].Points.Clear();
            chart1.Series["PA Output w/o DPD"].Points.Clear();
            chart1.Series["Origin Signal"].Points.Clear();
            var origFreq = _dpdApplication.GetOrigFreq();
            var origSig = _dpdApplication.GetOrigSig();
            var dpdPaOutFreq = _dpdApplication.GetDpdPaOutFreq();
            var dpdPaOutPower = _dpdApplication.GetDpdPaOutPower();
            var paOutFreq = _dpdApplication.GetStep2PaOutFreq();
            var paOutPower = _dpdApplication.GetStep2PaOutPower();
            if (origSig != null)
            {
                DrawOrigSig(origFreq, origSig);
            }
            if (dpdPaOutPower != null)
            {
                DrawDpdPaOutPower(dpdPaOutFreq, dpdPaOutPower);
            }
            if (paOutPower != null)
            {
                DrawPaOutPower(paOutFreq, paOutPower);
            }
        }

        private void InstrAddrTxt_TextChanged(object sender, EventArgs e)
        {
            string addr = InstrAddrTxt.Text;
            _dpdApplication.SetInstrAddr(addr);
        }

        private void BrowseButton_Click(object sender, EventArgs e)
        {
            var op = new OpenFileDialog();
            string path = "";
            if (op.ShowDialog() == DialogResult.OK)
            {
                path = op.FileName;
            }
            if (path != "")
            {
                _dpdApplication.SetVsaSetFile(path);
                VSASetTxt.Text = _dpdApplication.GetVsaSetFile();
            }
        }

        private void VSASetTxt_TextChanged(object sender, EventArgs e)
        {
            string path = VSASetTxt.Text;
            _dpdApplication.SetVsaSetFile(path);
        }

        private void MainForm_Closed(object sender, FormClosedEventArgs e)
        {
            if (_dpdApplication != null)
            {
                _dpdApplication.Close();
            }
        }

        private void ChooseFileButton_Click(object sender, EventArgs e)
        {
            var op = new OpenFileDialog {Filter = @"workspace file|*.wsv"};
            string path = "";
            if (op.ShowDialog() == DialogResult.OK)
            {
                path = op.FileName;
            }
            if (path != "")
            {
                ClearResult();
                DisableComponent();
                ChooseFileButton.Enabled = false;
                LoadwsvLabel.Enabled = false;
                PathLabel.Visible = false;
                LoadingLabel.Visible = true;
                if (_dpdApplication != null)
                {
                    _dpdApplication.Close();
                }
                _dpdApplication = new Dpd(path);
                LoadingLabel.Visible = false;
                EnableComponent();
                ChooseFileButton.Enabled = true;
                LoadwsvLabel.Enabled = true;
                PathLabel.Text = @"File Path: " + path;
                PathLabel.Visible = true;
                InitializeTextBox();
                Drawchart1();
                AcpResult();
                EvmResult();
                DpdResult();
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            try
            {
                _dpdApplication.Save();
            }
            catch
            {
                SaveAs();
                PathLabel.Text = @"File Path: " + _dpdApplication.FilePath();
            }
        }

        private void SaveAsButton_Click(object sender, EventArgs e)
        {
            SaveAs();
            PathLabel.Text = @"File Path: " + _dpdApplication.FilePath();
        }

        private void SaveAs()
        {
            var sa = new SaveFileDialog {Filter = @"workspace file|*.wsv"};
            string path = "";
            if (sa.ShowDialog() == DialogResult.OK)
            {
                path = sa.FileName;
            }
            if (path != "")
            {
                _dpdApplication.SaveAs(path);
            }
        }
    }
}
