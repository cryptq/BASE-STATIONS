﻿// Copyright 2014 Keysight Technologies, Inc , Keysight Confidential
using System;
using System.Windows.Forms;

namespace DPD_SFP
{
    public partial class Spectrum : Form
    {
        public Spectrum()
        {
            InitializeComponent();
        }

        internal void DrawOrigSig(double[] origFreq, double[] origSig)
        {
            for (int i = 0; i != origFreq.Length; ++i)
            {
                chart1.Series["Origin Signal"].Points.AddXY(origFreq[i] / 1e9, 10 * Math.Log(origSig[i] * 1e3, 10));
            }
        }

        internal void DrawPaOutPower(double[] paOutFreq, double[] paOutPower)
        {
            for (int i = 0; i != paOutFreq.Length; ++i)
            {
                chart1.Series["PA Output w/o DPD"].Points.AddXY(paOutFreq[i] / 1e9, 10 * Math.Log(paOutPower[i] * 1e3, 10));
            }
        }

        internal void DrawDpdPaOutPower(double[] dpdpaOutFreq, double[] dpdpaOutPower)
        {
            for (int i = 0; i != dpdpaOutFreq.Length; ++i)
            {
                chart1.Series["DPD-PA Output"].Points.AddXY(dpdpaOutFreq[i] / 1e9, 10 * Math.Log(dpdpaOutPower[i] * 1e3, 10));
            }
        }

    }
}
