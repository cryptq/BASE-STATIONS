﻿// Copyright 2014 Keysight Technologies, Inc , Keysight Confidential
using System.Globalization;

namespace DPD_SFP
{
    class Dpd
    {
        readonly SystemVueExample.SystemVue _systemVue;

        string _filename;

        string _filepath;

        private bool _bVisible;

        public Dpd(string path)
        {
            _filepath = path;

            _systemVue = new SystemVueExample.SystemVue();

            _systemVue.OpenWorkspace(_filepath);

            _filename = GetName(_filepath);

            _systemVue.Visible = Visible;
        }

        private static string GetName(string path)
        {
            string[] file = path.Split('\\');
            string[] name = file[file.Length - 1].Split('.');
            return name[0];
        }

        // Control SystemVue visibility
        public bool Visible
        {
            get { return _bVisible; }
            set
            {
                _bVisible = value;
                if (_systemVue != null)
                    _systemVue.Visible = value;
            }
        }

        internal string FilePath()
        {
            return _filepath;
        }

        internal void SetFCarrier(double carrfre)
        {
            ResetGlobalParams("FCarrier", carrfre.ToString(CultureInfo.InvariantCulture));
        }

        internal void SetOriRfPower(double rfpower)
        {
            ResetGlobalParams("OriginRFPower", rfpower.ToString(CultureInfo.InvariantCulture));
        }

        internal void SetTimeStart(double timestart)
        {
            ResetGlobalParams("TimeStart", timestart.ToString(CultureInfo.InvariantCulture));
        }

        internal void SetTimeStop(double timestop)
        {
            ResetGlobalParams("TimeStop", timestop.ToString(CultureInfo.InvariantCulture));
        }

        internal void SetMemoryOrder(double memorder)
        {
            ResetGlobalParams("MemoryOrder", memorder.ToString(CultureInfo.InvariantCulture));
        }

        internal void SetNonlinearOrder(double nonlinearorder)
        {
            ResetGlobalParams("NonlinearOrder", nonlinearorder.ToString(CultureInfo.InvariantCulture));
        }

        internal double[] GetOrigFreq()
        {

            return _systemVue.GetDataDoubleArray(_filename + ".DPD Flow.Step 5 Verify DPD Response.Step 5,3 Spectrum Comparison.SpectrumPlotComparison.Eqns.VarBlock.Origin_Sig_Power_Freq");
        }

        internal double[] GetOrigSig()
        {
            return _systemVue.GetDataDoubleArray(_filename + ".DPD Flow.Step 5 Verify DPD Response.Step 5,3 Spectrum Comparison.SpectrumPlotComparison.Eqns.VarBlock.Origin_Sig_Power");
        }

        internal double[] GetDpdPaOutFreq()
        {
            return _systemVue.GetDataDoubleArray(_filename + ".DPD Flow.Step 5 Verify DPD Response.Step 5,3 Spectrum Comparison.SpectrumPlotComparison.Eqns.VarBlock.DPD_PAOutput_Power_Freq");
        }

        internal double[] GetDpdPaOutPower()
        {
            return _systemVue.GetDataDoubleArray(_filename + ".DPD Flow.Step 5 Verify DPD Response.Step 5,3 Spectrum Comparison.SpectrumPlotComparison.Eqns.VarBlock.DPD_PAOutput_Power");
        }

        internal double[] GetStep2PaOutFreq()
        {
            return _systemVue.GetDataDoubleArray(_filename + ".DPD Flow.Step 5 Verify DPD Response.Step 5,3 Spectrum Comparison.SpectrumPlotComparison.Eqns.VarBlock.Step2_PAOutput_Power_Freq");
        }

        internal double[] GetStep2PaOutPower()
        {
            return _systemVue.GetDataDoubleArray(_filename + ".DPD Flow.Step 5 Verify DPD Response.Step 5,3 Spectrum Comparison.SpectrumPlotComparison.Eqns.VarBlock.Step2_PAOutput_Power");
        }

        internal double GetDpdOutputPower()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.DPD_PAOutPower");
        }

        internal void RunCreateDpdStimulusAnalysis()
        {
            _systemVue.RunScript(_filename + ".[DPD Flow].[Step 1 Create DPD Stimulus].[CreateDPDStimulus Analysis].RunAnalysis()");
        }

        internal void RunAdjustRfPowerAnalysis()
        {
            _systemVue.RunScript(_filename + ".[DPD Flow].[Step 2 Capture DUT Response].[Step 2.1-1 Save Baseband Input].[AdjustRFPower Analysis].RunAnalysis()");
        }

        internal void RunCaptureDutResponseAnalysis()
        {
            _systemVue.RunScript(_filename + ".[DPD Flow].[Step 2 Capture DUT Response].[Step 2.2 Capture DUT Response].[CaptureDUTResponse Analysis].RunAnalysis()");
        }

        internal void RunDutModelExtractionAnalysis()
        {
            _systemVue.RunScript(_filename + ".[DPD Flow].[Step 3 DUT Model Extraction].[DUTModelExtraction Analysis].RunAnalysis()");
        }

        internal void RunPowerAlignmentAnalysis()
        {
            _systemVue.RunScript(_filename + ".[DPD Flow].[Step 4 DPD Response].[Step 4.1 Power Alignment].PowerAlignment_Analysis.RunAnalysis()");
        }

        internal void RunApply_DPDAnalysis()
        {
            _systemVue.RunScript(_filename + ".[DPD Flow].[Step 4 DPD Response].[Step 4.2 Apply DPD].Apply_DPD_Analysis.RunAnalysis()");
        }

        internal void RunCaptureDPD_PAOutputDataAnalysis()
        {
            _systemVue.RunScript(_filename + ".[DPD Flow].[Step 4 DPD Response].[Step 4.3 Capture DPD-PA Output Waveform].[CaptureDPD-PAOutputData Analysis].RunAnalysis()");
        }

        internal void RunSpectrumPlotAnalysis()
        {
            _systemVue.RunScript(_filename + ".[DPD Flow].[Step 5 Verify DPD Response].[Step 5.3 Spectrum Comparison].[SpectrumPlot Analysis].RunAnalysis()");
        }

        internal double GetAcpLowerOrig()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.ACP_Lower_Orig");
        }

        internal double GetAcpLowerWdpd()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.ACP_Lower_wDPD");
        }

        internal double GetAcpLowerWodpd()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.ACP_Lower_woDPD_Step2");
        }

        internal double GetAcpUpperOrig()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.ACP_Upper_Orig");
        }

        internal double GetAcpUpperWdpd()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.ACP_Upper_wDPD");
        }

        internal double GetAcpUpperWodpd()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.ACP_Upper_woDPD_Step2");
        }

        internal void RunCalEquationAcp()
        {
            _systemVue.RunScript(_filename + ".[DPD Flow].[Step 5 Verify DPD Response].[Step 5.3 Spectrum Comparison].EquationACP.Calculate()");
        }

        internal void RunCalEquationEvm()
        {
            _systemVue.RunScript(_filename + ".[DPD Flow].[Step 5 Verify DPD Response].[Step 5.3 Spectrum Comparison].EquationEVM.Calculate()");
        }

        internal void RunCalEquationDPD_PAPower()
        {
            _systemVue.RunScript(_filename + ".[DPD Flow].[Step 4 DPD Response].[Step 4.4 Get DPD-PA Characteristics].DPD_PAPower.Calculate()");
        }

        internal double GetEvmOrig()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.EVM_Orig");
        }

        internal double GetEvmwdpd()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.EVM_wDPD");
        }

        internal double GetEvmwodpd()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.EVM_woDPD_Step2");
        }

        internal double GetCarrFreq()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.FCarrier");
        }

        internal double GetOriRfPower()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.OriginRFPower");
        }

        internal double GetTimeStart()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.TimeStart");
        }

        internal double GetTimeStop()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.TimeStop");
        }

        internal double GetNonlinearOrder()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.NonlinearOrder");
        }

        internal double GetMemOrder()
        {
            return _systemVue.GetDataDouble(_filename + ".WorkspaceVariables.VarBlock.MemoryOrder");
        }

        internal string GetPrimAddress()
        {
            string type = _systemVue.GetDataType(_filename + ".WorkspaceVariables.VarBlock.PrimAddress");
            if (type == "Array of Word")
            {
                var pri = _systemVue.GetDataUshortArray(_filename + ".WorkspaceVariables.VarBlock.PrimAddress");
                var u = new ushort[pri.GetLength(0) * pri.GetLength(1)];
                var i = 0;
                string str = null;
                for (int j = 0; j != pri.GetLength(0); ++j)
                    for (int k = 0; k != pri.GetLength(1); ++k)
                    {
                        u[i] = pri[j, k];
                        ++i;
                    }
                for (int j = 0; j != u.Length; ++j)
                {
                    str += char.ConvertFromUtf32(u[j]);
                }
                return str;
            }
            else
            {
                string str = _systemVue.GetDataString(_filename + ".WorkspaceVariables.VarBlock.PrimAddress");
                return str;
            }
        }

        internal string GetVsaSetFile()
        {

            string type = _systemVue.GetDataType(_filename + ".WorkspaceVariables.VarBlock.SetupFile");
            if (type == "Array of Word")
            {
                var pri = _systemVue.GetDataUshortArray(_filename + ".WorkspaceVariables.VarBlock.SetupFile");
                var u = new ushort[pri.GetLength(0) * pri.GetLength(1)];
                var i = 0;
                string str = null;
                for (var j = 0; j != pri.GetLength(0); ++j)
                    for (var k = 0; k != pri.GetLength(1); ++k)
                    {
                        u[i] = pri[j, k];
                        ++i;
                    }
                for (var j = 0; j != u.Length; ++j)
                {
                    str += char.ConvertFromUtf32(u[j]);
                }
                return str;
            }
            else
            {
                string str = _systemVue.GetDataString(_filename + ".WorkspaceVariables.VarBlock.SetupFile");
                return str;
            }
        }

        internal void SetInstrAddr(string addr)
        {
            ResetGlobalParams("PrimAddress", "\'" + addr + "\'");
        }

        internal void SetVsaSetFile(string path)
        {
            ResetGlobalParams("SetupFile", "\'" + path + "\'");
        }

        internal void Close()
        {
            _systemVue.Exit();
        }

        internal string GetGlobalParaText()
        {
            return _systemVue.GetTextString(_filename + ".GlobalParams");
        }

        internal void RefreshGolobalParaText(string text)
        {
            string path = _filename + ".GlobalParams";
            _systemVue.RefreshEquations(path, text);
        }

        internal void ResetGlobalParams(string parameter, string value)
        {
            string text = GetGlobalParaText();
            text = text.Replace("\r", "");
            string[] textArr = text.Split('\n');
            text = "";
            for (int i = 0; i != textArr.Length; ++i)
            {
                if (textArr[i].StartsWith(parameter))
                {
                    textArr[i] = parameter + " = " + value + ";";
                }
                text += textArr[i];
                text += "\n";
            }
            text = text.Substring(0, text.Length - 1);
            string path = _filename + ".GlobalParams";
            _systemVue.RefreshEquations(path, text);
        }

        internal void Save()
        {
            _systemVue.Save();
        }

        internal void SaveAs(string path)
        {
            _systemVue.SaveAs(path);
            _systemVue.SaveAs(path);
            _filepath = path;
            _filename = GetName(_filepath);
        }
    }
}