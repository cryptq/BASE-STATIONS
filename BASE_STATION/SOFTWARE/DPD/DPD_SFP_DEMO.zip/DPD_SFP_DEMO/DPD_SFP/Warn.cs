﻿// Copyright 2014 Keysight Technologies, Inc , Keysight Confidential
using System;
using System.Windows.Forms;

namespace DPD_SFP
{
    public partial class Warn : Form
    {
        public Warn()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        public void Label(string text)
        {
            label1.Text = text;
        }
    }
}
