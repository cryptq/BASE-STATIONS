﻿// Copyright 2014 Keysight Technologies, Inc , Keysight Confidential
using System;
using System.IO;

namespace SystemVueExample
{
    public class SystemVue
    {
        // Instance of SystemVue application
        readonly GENESYS.Application _app;

        // Constructor, called when a instance of this class is created
        public SystemVue()
        {
            try
            {
                // Start a new instance of SystemVue
                _app = new GENESYS.Application();
            }
            catch
            {
                // If we have a exception, the COM server is probably not registered.  
                // Register it by running SystemVue.exe /regserver
                _app = null;
            }

        }

        // Member boolean to track visibility
        bool _bVisible;

        // Method to set/get Visible property of SystemVue - by default SystemVue will start hidden under COM control
        public bool Visible
        {
            get { return _bVisible; }
            set
            {
                _bVisible = value;
                if (_app != null)
                {
                    _app.Application.Visible = _bVisible;
                }
            }
        }

        // Some external environments need a separate method to set visibility
        public void SetVisible(bool bVisible)
        {
            Visible = bVisible;
        }

        // Run a VB script command
        public bool RunScript(string csScript)
        {
            var bStatus = true;

            try
            {
                // Run a script, assuming Visual Basic
                _app.Application.RunScript(csScript);
            }
            catch
            {
                bStatus = false;
            }

            return bStatus;
        }

        // Open a workspace, given the path
        public bool OpenWorkspace(string sPath)
        {
            var sCommand = "OpenWorkspace(\"";
            sCommand += sPath.Replace('/', '\\'); // SystemVue 2011.10 and earlier must have backslashes
            sCommand += "\")";
            return RunScript(sCommand);
        }

        public bool OpenExampleWorkspace(string sPath)
        {
            var sCommand = "FileOpenExample(\"";
            sCommand += sPath.Replace('/', '\\'); // SystemVue 2011.10 and earlier must have backslashes
            sCommand += "\")";
            return RunScript(sCommand);
        }

        private void SetAutoCalcOff(string sParamPath)
        {
            // See if this is a varblock and turn off automation
            try
            {
                var iIndex = sParamPath.IndexOf(".VarBlock", StringComparison.Ordinal); // if not found, exception thrown and caught below
                var sVarBlockPath = sParamPath.Remove(iIndex);
                GetItem(sVarBlockPath);
                RunScript("autocalc=false\r\n" + sVarBlockPath + ".SetProperty \"AutoCalc\", autocalc");
            }
            catch{}// If not found, ignore as it is not equation block
        }

        //refresh equations
        public bool RefreshEquations(string path, string text)
        {
            var bSuccess = RewriteEquationsText(path, text);
            CalculateEquations(path);
            return bSuccess;
        }

        private void CalculateEquations(string path)
        {
            RunScript(path + ".Calculate()");
        }

        //rewrite equations' text
        public bool RewriteEquationsText(string textPath, string text)
        {
            if (text.EndsWith("\n"))
            {
                text = text.Substring(0, text.Length - 1);
            }

            var textArr = text.Split('\n');
            text = "";
            foreach (var paraText in textArr)
            {
                text += "\"" + paraText + "\"";
                text += " + chr(10) + ";
            }

            if (text.EndsWith(" + "))
            {
                text = text.Substring(0, text.Length - 3);
            }

            var bSuccess = RunScript("text = " + text + "\n" + textPath + ".SetProperty \"Text\", text");
            return bSuccess;
        }

        // Set a scalar double parameter
        public bool SetStringParameter(string sParamPath, string sParamValue)
        {
            SetAutoCalcOff(sParamPath);
            var bSuccess = RunScript(sParamPath + ".Set( \"'" + sParamValue + "\" )");
            return bSuccess;
        }

        // Set a scalar double parameter
        public bool SetParameter(string sParamPath, double sParamValue)
        {
            SetAutoCalcOff(sParamPath);
            var bSuccess = RunScript(sParamPath + ".Set( " + sParamValue + " )");
            return bSuccess;
        }

        //Get data type
        public string GetDataType(string sDataName)
        {
            var item = GetItem(sDataName);

            if (item == null) return null;
            for (var i = 0; i < item.GetVarCount(); i++)
            {
                var itemName = item.GetVarName(i);
                if (itemName == "Data")
                {
                    return item.GetVarType(i);
                }
            }
            return null;
        }

        // Get data from dataset, assuming double array[,]
        public ushort[,] GetDataUshortArray(string sDataName)
        {
            var item = GetItem(sDataName);

            if (item == null) return null;
            for (var i = 0; i < item.GetVarCount(); i++)
            {
                var itemName = item.GetVarName(i);
                if (itemName == "Data")
                {
                    var type = item.GetVarType(i);
                    Console.WriteLine(type);
                    return (ushort[,]) item.GetVarValue(i);
                }
            }
            return null;
        }

        // Get data from dataset, assuming double array
        public double[] GetDataDoubleArray(string sDataName)
        {
            var item = GetItem(sDataName);

            if (item == null) return null;
            for (int i = 0; i < item.GetVarCount(); i++)
            {
                var itemName = item.GetVarName(i);
                if (itemName == "Data")
                {
                    return (double[])item.GetVarValue(i);
                }
            }
            return null;
        }

        //Get data from dataset, assuming double
        public double GetDataDouble(string sDataName)
        {
            var item = GetItem(sDataName);
            const double data = 0;

            if (item == null) return data;
            for (var i = 0; i < item.GetVarCount(); i++)
            {
                string itemName = item.GetVarName(i);
                if (itemName == "Data")
                {
                    if (item.GetVarValue(i) != null)
                    {
                        //data = (double)(((GENESYS.IItem)item).GetVarValue(i));
                        return (double)item.GetVarValue(i);
                    }
                }
            }
            return data;
        }

        // Find a item in a Genesys item
        public GENESYS.IItem GetItem(string sItemName)
        {
            GENESYS.IItem me = null;
            if (_app != null)
            {
                me = (GENESYS.IItem)_app.Manager;
                me = GetItem(me, sItemName);
            }
            return me;
        }

        // Find a item, given a path
        static GENESYS.IItem GetItem(GENESYS.IItem parent, string sItemName)
        {
            var item = parent;

            var path = sItemName.Split('.');
            try
            {
                foreach (var itemName in path)
                {
                    if (item == null) continue;
                    item.GetItemCount();
                    var itemname = itemName.Replace(",", ".");
                    item = item.GetItemByName(itemname);
                }
            }
            catch
            {
                item = null;
            }
            return item;
        }

        //Get data from dataset, assuming string
        public string GetDataString(string sDataName)
        {
            var item = GetItem(sDataName);
            const string data = "";

            if (item == null) return data;
            for (var i = 0; i < item.GetVarCount(); i++)
            {
                string itemName = item.GetVarName(i);
                if (itemName == "Data")
                {
                    return (string)item.GetVarValue(i);
                }
            }
            return data;
        }

        //Get text from dataset, assuming string
        public string GetTextString(string sDataName)
        {
            var item = GetItem(sDataName);
            var text = "";

            if (item == null) return text;
            for (var i = 0; i < item.GetVarCount(); i++)
            {
                var itemName = item.GetVarName(i);
                if (itemName == "Text")
                {
                    text = (string)item.GetVarValue(i);
                    break;
                }
            }
            return text;
        }

        //Exit without saving
        public void Exit()
        {
            // Close and save all workspaces
            for (var i = 0; i < _app.Manager.GetWorkspaceCount(); i++)
            {
                var workspace = _app.Manager.GetWorkspaceByIndex(i);
                // COM interface does not support quitting without saving, so save to temp file, and then delete it
                var file = Path.GetTempFileName();
                workspace.SaveAs(file);
                File.Delete(file);
            }

            // Quit the application
            if (_app != null)
                _app.Quit();
        }

        //Save as
        public void SaveAs(string file)
        {
            for (int i = 0; i < _app.Manager.GetWorkspaceCount(); i++)
            {
                var workspace = _app.Manager.GetWorkspaceByIndex(i);
                workspace.SaveAs(file);
            }
        }

        //Save
        public void Save()
        {
            for (var i = 0; i < _app.Manager.GetWorkspaceCount(); i++)
            {
                GENESYS.Workspace workspace = _app.Manager.GetWorkspaceByIndex(i);
                workspace.Save();
            }
        }
    }
}
