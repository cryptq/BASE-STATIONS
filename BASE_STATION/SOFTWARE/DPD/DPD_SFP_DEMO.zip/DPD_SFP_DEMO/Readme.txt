========================================================================
    DPD SFP Demo
========================================================================
This document is to summarize the files that make up this demo, and to assist
you to run the demo "DPD_SFP.exe" in the current directory.

------------------------------------------------------------------------
Files structure
------------------------------------------------------------------------
DPD_SFP.sln
	Top Visual Studio solution.

Project DPD_SFP -> DPD_SFP.exe.
	Dpd.cs, Program.cs,
	MainForm.cs, Spectrum.cs and Warn.cs.

Project SystemVueExample -> SystemVueExample.dll
	SystemVue.cs.

SystemVue.cs
	Class and methods to call SystemVue.exe, open/exit/save workspace, get/set parameters, run VB script.

Dpd.cs
	Class and methods to process DPD_UserDefined.wsv, get/set DPD parameters, Run analysis.

Program.cs
	Main entrance of the DPD_SFP UI.

MainForm.cs
	Main start-up UI components for DPD_SFP.exe.

Spectrum.cs
	Large Spectrum plot UI.

Warn.cs
	Warning pop-up UI.

------------------------------------------------------------------------
How to run this demo.
------------------------------------------------------------------------
1.Build DPD_SFP.sln to generate/update ./DPD_SFP/bin/Release/DPD_SFP.exe 
  and ./DPD_SFP/bin/Release/SystemVueExample.dll.

2.Run DPD_SFP.exe.

3.Click "Browse..." to load DPD workspace file 
  "<SystemVueInstallDir>/Examples/DPD/DPD UserDefined HardwareVerification/DPD_UserDefined.wsv".
  SystemVue will load the workspace in background, this will take several minutes.

4.When workspace is loaded, all parameters and results will be updated from the workspace, 
  you can change the parameters and click "Start Running Analysis" to re-run the workspace.